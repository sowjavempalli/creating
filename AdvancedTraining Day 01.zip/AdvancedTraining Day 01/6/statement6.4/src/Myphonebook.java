import java.io.*;
import java.sql.*;
import java.util.*;
 
public class Myphonebook {
	public static String help_msg=	"Press:   -  1 \n Add contact  -  2 \n Search by name  - 3  Exit :";
	public static void main(String[] args) {	
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		System.out.println("\n\n** Welcome to MyPhone Book **\n\n");
		System.out.print("[Main Menu] "+help_msg+"\n:");
		Scanner s=new Scanner(System.in);		
		for(;;){
			
				String command=s.nextLine().trim();				
				if (command.equalsIgnoreCase("1")){
					System.out.print("Type in contact details in the format: Phone and Name\n:");
					
					System.out.println("enter phno");
					int phno=s.nextInt();
					s.nextLine();
					System.out.println("enter name");
					String name=s.nextLine();
					hm.put(phno, name);
					System.out.println("your details  are added");
 
				}else if (command.equalsIgnoreCase("2")){
					System.out.print("Type in the phno you are searching for :\n:");
					
					int phno=s.nextInt();
					
					System.out.println("your name is "+hm.get(phno));
 
				}else if (command.equalsIgnoreCase("3")){
					System.out.println("Good Bye User....");
					System.exit(0);
				}else{					
					System.out.print("Unknown command ! Try again \n:");
				}
 
		}
 
	}
 
}
